<?php
	$metas = array(
		"mal" => array(
			"title" => "Compatibilidad Futbolera",
			"description" => "Amig@, date cuenta. Parece que su relación no durará mucho, así como los DTs en el Veracruz. Pero calma, que aún pueden cambiar para que todo mejore.",
			"image" => "images/respuestas/4.png" 
		),
		"algo" => array(
			"title" => "Compatibilidad Futbolera",
			"description" => "Vaya que su relación no ha sido fácil pero cuál lo es, ni la de Messi y Argentina lo es, pero al final el amor puede con cualquier cosa.",
			"image" => "images/respuestas/3.png" 
		),
		"maso" => array(
			"title" => "Compatibilidad Futbolera",
			"description" => "Aunque no coordinan en todo, a ti y a tu pareja los une la pasión por el futbol. Ya sabes que no hay romance perfecto, ni el de Cristiano con el Madrid lo fue… así que venga ¡Vayan por todo!",
			"image" => "images/respuestas/2.png" 
		),
		"bien" => array(
			"title" => "Compatibilidad Futbolera",
			"description" => "Son la pareja perfecta, como los tacos y el balón, como el Cruz Azul y los subcampeonatos, como el jersey al jugador. Messi y Antonella no son nada a lado de ustedes",
			"image" => "images/respuestas/1.png" 
		),
	);